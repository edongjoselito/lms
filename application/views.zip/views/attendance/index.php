<div class="data-table">
    <div class="table-header">
        <h5><i class="bi bi-calendar-check-fill me-2"></i>Attendance</h5>
        <form class="d-flex gap-2 align-items-center" method="get" action="<?= site_url('attendance') ?>">
            <input type="date" class="form-control form-control-sm" name="date" value="<?= $date ?>" style="width:160px;border-radius:8px;">
            <button type="submit" class="btn btn-dark btn-sm" style="border-radius:8px;">Go</button>
        </form>
    </div>

    <?php if (!empty($records)): ?>
    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <th>Student</th>
                    <th>Email</th>
                    <th>Login Time</th>
                    <th>Logout Time</th>
                    <th>Duration</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($records as $r): ?>
                    <tr>
                        <td style="font-weight:600;"><?= htmlspecialchars($r->name) ?></td>
                        <td style="color:#64748b;"><?= htmlspecialchars($r->email) ?></td>
                        <td><?= $r->login_time ? date('g:ia', strtotime($r->login_time)) : '-' ?></td>
                        <td><?= $r->logout_time ? date('g:ia', strtotime($r->logout_time)) : '<span style="color:#f59e0b;font-weight:600;">Online</span>' ?></td>
                        <td>
                            <?php if ($r->duration_minutes > 0): ?>
                                <?php
                                $hours = floor($r->duration_minutes / 60);
                                $mins = $r->duration_minutes % 60;
                                echo $hours > 0 ? "{$hours}h {$mins}m" : "{$mins}m";
                                ?>
                            <?php elseif ($r->logout_time): ?>
                                <span style="color:#94a3b8;">-</span>
                            <?php else: ?>
                                <span style="color:#6366f1;font-weight:600;">Active</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php else: ?>
    <div class="p-5 text-center" style="color:#94a3b8;">
        <i class="bi bi-calendar-x" style="font-size:2.5rem;"></i>
        <p style="margin-top:0.75rem;">No attendance records for <?= date('F j, Y', strtotime($date)) ?>.</p>
    </div>
    <?php endif; ?>
</div>
