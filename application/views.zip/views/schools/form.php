<!-- Hero Section -->
<div class="dashboard-hero">
    <div class="hero-content">
        <h1 class="hero-title"><?= ($school) ? 'Edit School' : 'Add New School' ?></h1>
        <p class="hero-subtitle"><?= ($school) ? 'Update school information and settings' : '' ?></p>
    </div>
</div>

<div class="row">
    <div class="col-12">
        <div class="mb-3">
            <a href="<?= site_url('schools') ?>" class="back-link">
                <i class="bi bi-arrow-left me-1"></i> Back to Schools
            </a>
        </div>
        <div class="form-card">
            <h5 class="form-card-title">
                <i class="bi bi-building me-2"></i>
                <?= ($school) ? 'Edit School' : 'School Information' ?>
            </h5>
            <?= form_open(($school) ? 'schools/edit/' . $school->id : 'schools/create', array('enctype' => 'multipart/form-data')) ?>
                <?php if (isset($is_school_admin) && $is_school_admin): ?>
                    <!-- School Admin View - Editable Fields -->
                    <div class="form-section">
                        <h6 class="section-title"><i class="bi bi-info-circle me-2"></i>School Information</h6>
                        <div class="row g-3">
                            <div class="col-12">
                                <label class="form-label">School Name</label>
                                <input type="text" class="form-control form-control-lg" value="<?= htmlspecialchars($school->name) ?>" disabled>
                                <small class="text-muted">Contact Super Admin to change school name</small>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">School ID Number</label>
                                <input type="text" class="form-control" value="<?= htmlspecialchars($school->school_id_number) ?>" disabled>
                                <small class="text-muted">Contact Super Admin to change school ID</small>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">School Type</label>
                                <input type="text" class="form-control" value="<?= ucfirst($school->type) ?>" disabled>
                                <small class="text-muted">Contact Super Admin to change school type</small>
                            </div>
                        </div>
                    </div>

                    <!-- Contact Information -->
                    <div class="form-section">
                        <h6 class="section-title"><i class="bi bi-telephone me-2"></i>Contact Information</h6>
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label">Email Address <span class="text-danger">*</span></label>
                                <input type="email" class="form-control" name="email" value="<?= htmlspecialchars($school->email ?? '') ?>" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Contact Number</label>
                                <input type="text" class="form-control" name="contact_number" value="<?= htmlspecialchars($school->contact_number ?? '') ?>">
                            </div>
                        </div>
                    </div>

                    <!-- Location -->
                    <div class="form-section">
                        <h6 class="section-title"><i class="bi bi-geo-alt me-2"></i>Location</h6>
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label">Division</label>
                                <input type="text" class="form-control" name="division" value="<?= htmlspecialchars($school->division ?? '') ?>">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Region</label>
                                <input type="text" class="form-control" name="region" value="<?= htmlspecialchars($school->region ?? '') ?>">
                            </div>
                            <div class="col-12">
                                <label class="form-label">Complete Address</label>
                                <textarea class="form-control" name="address" rows="3"><?= htmlspecialchars($school->address ?? '') ?></textarea>
                            </div>
                        </div>
                    </div>

                    <!-- School Logo -->
                    <div class="form-section">
                        <h6 class="section-title"><i class="bi bi-image me-2"></i>School Logo</h6>
                        <div class="row g-3">
                            <div class="col-12">
                                <div class="logo-upload-section">
                                    <?php if ($school->logo): ?>
                                        <div class="current-logo">
                                            <img src="<?= base_url($school->logo) ?>" alt="School Logo" class="logo-preview">
                                            <button type="button" class="btn-remove-logo" onclick="confirmRemoveLogo()">
                                                <i class="bi bi-trash"></i> Remove
                                            </button>
                                        </div>
                                    <?php endif; ?>
                                    <input type="file" class="form-control" name="logo" id="logoInput" accept="image/jpeg,image/jpg,image/png,image/gif,image/webp">
                                    <input type="hidden" name="remove_logo" id="removeLogoInput" value="0">
                                    <small class="text-muted">Accepted formats: JPG, PNG, GIF, WebP. Maximum size: 2MB. Recommended size: 200x200px.</small>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php else: ?>
                    <!-- Super Admin View - All Fields -->
                    <!-- Basic Information -->
                    <div class="form-section">
                        <h6 class="section-title"><i class="bi bi-info-circle me-2"></i>Basic Information</h6>
                        <div class="row g-3">
                            <div class="col-12">
                                <label class="form-label">School Name <span class="text-danger">*</span></label>
                                <input type="text" class="form-control form-control-lg" name="name" id="school_name" value="<?= ($school) ? htmlspecialchars($school->name) : '' ?>" required oninput="this.value = this.value.toUpperCase()">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">School ID Number <span class="text-danger">*</span></label>
                                <div class="input-group">
                                    <input type="text" class="form-control" name="school_id_number" id="school_id_number" value="<?= ($school) ? htmlspecialchars($school->school_id_number) : '' ?>" required>
                                    <button type="button" class="btn btn-outline-secondary" onclick="generateSchoolId()">
                                        <i class="bi bi-shuffle"></i> Generate
                                    </button>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">School Type <span class="text-danger">*</span></label>
                                <select class="form-select" name="type" required>
                                    <option value="deped" <?= ($school && $school->type == 'deped') ? 'selected' : '' ?>>DepEd (K-12)</option>
                                    <option value="ched" <?= ($school && $school->type == 'ched') ? 'selected' : '' ?>>CHED (Higher Ed)</option>
                                    <option value="tesda" <?= ($school && $school->type == 'tesda') ? 'selected' : '' ?>>TESDA (Tech-Voc)</option>
                                    <option value="both" <?= ($school && $school->type == 'both') ? 'selected' : '' ?>>All (K-12, CHED, TESDA)</option>
                                </select>
                            </div>
                            <?php if ($school): ?>
                            <div class="col-12">
                                <label class="form-label">School Logo</label>
                                <div class="logo-upload-section">
                                    <?php if ($school->logo): ?>
                                        <div class="current-logo">
                                            <img src="<?= base_url($school->logo) ?>" alt="School Logo" class="logo-preview">
                                            <button type="button" class="btn-remove-logo" onclick="confirmRemoveLogo()">
                                                <i class="bi bi-trash"></i> Remove
                                            </button>
                                        </div>
                                    <?php endif; ?>
                                    <input type="file" class="form-control" name="logo" id="logoInput" accept="image/jpeg,image/jpg,image/png,image/gif,image/webp">
                                    <input type="hidden" name="remove_logo" id="removeLogoInput" value="0">
                                    <small class="text-muted">Accepted formats: JPG, PNG, GIF, WebP. Maximum size: 2MB. Recommended size: 200x200px.</small>
                                </div>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>

                <!-- Contact Information -->
                <div class="form-section">
                    <h6 class="section-title"><i class="bi bi-telephone me-2"></i>Contact Information</h6>
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">Email Address <span class="text-danger">*</span></label>
                            <input type="email" class="form-control" name="email" value="<?= ($school) ? htmlspecialchars($school->email) : '' ?>" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Contact Number</label>
                            <input type="text" class="form-control" name="contact_number" value="<?= ($school) ? htmlspecialchars($school->contact_number) : '' ?>">
                        </div>
                    </div>
                </div>

                <!-- Location -->
                <div class="form-section">
                    <h6 class="section-title"><i class="bi bi-geo-alt me-2"></i>Location</h6>
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">Division</label>
                            <input type="text" class="form-control" name="division" value="<?= ($school) ? htmlspecialchars($school->division) : '' ?>">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Region</label>
                            <input type="text" class="form-control" name="region" value="<?= ($school) ? htmlspecialchars($school->region) : '' ?>">
                        </div>
                        <div class="col-12">
                            <label class="form-label">Complete Address</label>
                            <textarea class="form-control" name="address" rows="3"><?= ($school) ? htmlspecialchars($school->address) : '' ?></textarea>
                        </div>
                    </div>
                </div>

                <?php if ($school): ?>
                    <!-- Status -->
                    <div class="form-section">
                        <h6 class="section-title"><i class="bi bi-toggle-on me-2"></i>Status</h6>
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" name="status" value="1" id="statusSwitch" <?= ($school->status) ? 'checked' : '' ?>>
                            <label class="form-check-label" for="statusSwitch">School is active and can be accessed</label>
                        </div>
                    </div>

                    <!-- School Admin Account -->
                    <div class="form-section">
                        <h6 class="section-title"><i class="bi bi-person-lock me-2"></i>School Admin Account</h6>
                        <?php if (isset($school_admin) && $school_admin): ?>
                            <div class="admin-info-box">
                                <div class="admin-info-item">
                                    <label class="admin-info-label">Email / Username</label>
                                    <div class="admin-info-value-with-copy">
                                        <span class="admin-info-value"><?= htmlspecialchars($school_admin->email) ?></span>
                                        <button type="button" class="btn-copy-small" onclick="copyAdminEmail('<?= htmlspecialchars($school_admin->email) ?>')">
                                            <i class="bi bi-copy"></i>
                                        </button>
                                    </div>
                                </div>
                                <div class="admin-info-item">
                                    <label class="admin-info-label">Password</label>
                                    <div class="admin-info-value-with-copy">
                                        <span class="admin-info-value password-display" id="adminPasswordDisplay">
                                            <?php if (isset($reset_password) && $reset_password): ?>
                                                <span id="passwordText"><?= htmlspecialchars($reset_password) ?></span>
                                            <?php else: ?>
                                                <span id="passwordText">••••••••••••</span>
                                            <?php endif; ?>
                                        </span>
                                        <button type="button" class="btn-copy-small" onclick="togglePasswordVisibility()" id="togglePasswordBtn">
                                            <i class="bi bi-eye" id="togglePasswordIcon"></i>
                                        </button>
                                        <?php if (isset($reset_password) && $reset_password): ?>
                                            <button type="button" class="btn-copy-small" onclick="copyAdminPassword('<?= htmlspecialchars($reset_password) ?>')">
                                                <i class="bi bi-copy"></i>
                                            </button>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="admin-actions">
                                    <a href="<?= site_url('schools/reset_admin_password/' . $school->id) ?>" class="btn btn-warning-custom">
                                        <i class="bi bi-key me-2"></i>Reset Password
                                    </a>
                                </div>
                            </div>
                        <?php else: ?>
                            <div class="alert alert-info">
                                <i class="bi bi-info-circle me-2"></i>
                                No School Admin account found for this school.
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
                <?php endif; ?>

                <div class="form-actions">
                    <button type="submit" class="btn-primary-custom"><i class="bi bi-check-lg"></i> Save School</button>
                    <a href="<?= site_url('schools') ?>" class="btn btn-light">Cancel</a>
                </div>
            <?= form_close() ?>
        </div>
    </div>
</div>

<style>
    .dashboard-hero {
        margin-bottom: 1.25rem;
    }

    .hero-content {
        padding: 0;
    }

    .hero-title {
        font-size: 1.5rem;
        font-weight: 600;
        color: #1e293b;
        margin-bottom: 0.25rem;
    }

    .hero-subtitle {
        color: #64748b;
        font-size: 0.875rem;
        margin: 0;
    }

    .back-link {
        color: #64748b;
        text-decoration: none;
        font-size: 0.9rem;
        font-weight: 500;
        display: inline-flex;
        align-items: center;
        transition: color 0.2s;
    }

    .back-link:hover {
        color: #1e293b;
    }

    .form-card {
        background: #ffffff;
        border-radius: 12px;
        border: 1px solid #e2e8f0;
        padding: 1.75rem;
    }

    .form-card-title {
        font-weight: 700;
        margin-bottom: 1.5rem;
        color: #1e293b;
        font-size: 1.1rem;
    }

    .form-section {
        margin-bottom: 1.75rem;
        padding-bottom: 1.75rem;
        border-bottom: 1px solid #e2e8f0;
    }

    .form-section:last-of-type {
        border-bottom: none;
        margin-bottom: 0;
        padding-bottom: 0;
    }

    .logo-upload-section {
        background: #f8fafc;
        border: 1px dashed #cbd5e1;
        border-radius: 8px;
        padding: 1.25rem;
    }

    .current-logo {
        display: inline-flex;
        align-items: center;
        gap: 1rem;
        margin-bottom: 1rem;
    }

    .logo-preview {
        width: 80px;
        height: 80px;
        object-fit: contain;
        border-radius: 8px;
        border: 1px solid #e2e8f0;
        background: white;
    }

    .btn-remove-logo {
        padding: 0.4rem 0.8rem;
        background: #fee2e2;
        color: #dc2626;
        border: none;
        border-radius: 6px;
        font-size: 0.8rem;
        font-weight: 500;
        cursor: pointer;
        transition: all 0.2s ease;
    }

    .btn-remove-logo:hover {
        background: #fecaca;
    }

    .section-title {
        font-size: 0.875rem;
        font-weight: 600;
        color: #3b82f6;
        margin-bottom: 1.25rem;
        display: flex;
        align-items: center;
        padding-bottom: 0.5rem;
    }

    .section-title i {
        font-size: 0.95rem;
    }

    .form-label {
        font-size: 0.85rem;
        font-weight: 500;
        color: #475569;
        margin-bottom: 0.5rem;
    }

    .form-control,
    .form-select {
        border: 1px solid #e2e8f0;
        border-radius: 8px;
        font-size: 0.9rem;
    }

    .form-control:focus,
    .form-select:focus {
        border-color: #3b82f6;
        box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
    }

    .form-control-lg {
        font-size: 1rem;
        padding: 0.75rem 1rem;
    }

    .form-actions {
        padding-top: 1.5rem;
        border-top: 1px solid #e2e8f0;
        display: flex;
        gap: 0.75rem;
    }

    .btn-light {
        border-radius: 10px;
        font-size: 0.875rem;
        font-weight: 500;
        padding: 0.6rem 1.25rem;
        border: 1px solid #e2e8f0;
        background: #fff;
        color: #64748b;
    }

    .btn-light:hover {
        background: #f8fafc;
        border-color: #cbd5e1;
        color: #1e293b;
    }

    .form-check-input:checked {
        background-color: #3b82f6;
        border-color: #3b82f6;
    }

    .input-group .btn-outline-secondary {
        border-radius: 0 8px 8px 0;
        border-left: none;
    }

    .input-group .form-control {
        border-radius: 8px 0 0 8px;
    }

    .admin-info-box {
        background: #f8fafc;
        border-radius: 10px;
        padding: 1.5rem;
        border: 1px solid #e2e8f0;
    }

    .admin-info-item {
        margin-bottom: 1.25rem;
    }

    .admin-info-item:last-child {
        margin-bottom: 0;
    }

    .admin-info-label {
        font-size: 0.8rem;
        font-weight: 600;
        color: #64748b;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        margin-bottom: 0.5rem;
        display: block;
    }

    .admin-info-value {
        font-size: 1rem;
        font-weight: 600;
        color: #1e293b;
        word-break: break-all;
    }

    .password-masked {
        font-family: monospace;
        letter-spacing: 2px;
    }

    .admin-actions {
        margin-top: 1.5rem;
        padding-top: 1.5rem;
        border-top: 1px solid #e2e8f0;
    }

    .btn-warning-custom {
        background: #f59e0b;
        color: #ffffff;
        border: none;
        border-radius: 10px;
        padding: 0.75rem 1.5rem;
        font-size: 0.875rem;
        font-weight: 500;
        text-decoration: none;
        display: inline-flex;
        align-items: center;
        transition: all 0.2s;
    }

    .btn-warning-custom:hover {
        background: #d97706;
        color: #ffffff;
    }

    .alert-info {
        background: #e0f2fe;
        border: 1px solid #bae6fd;
        border-radius: 10px;
        padding: 1rem;
        color: #0369a1;
        font-size: 0.9rem;
    }

    .admin-info-value-with-copy {
        display: flex;
        align-items: center;
        gap: 0.75rem;
    }

    .btn-copy-small {
        width: 32px;
        height: 32px;
        border-radius: 6px;
        border: 1px solid #e2e8f0;
        background: #ffffff;
        color: #64748b;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all 0.2s;
        flex-shrink: 0;
    }

    .btn-copy-small:hover {
        background: #f1f5f9;
        color: #1e293b;
        border-color: #cbd5e1;
    }
</style>

<script>
function generateSchoolId() {
    const prefix = 'SCH';
    const randomNum = Math.floor(10000 + Math.random() * 90000);
    const schoolId = prefix + '-' + randomNum;
    document.getElementById('school_id_number').value = schoolId;
}

function copyAdminEmail(email) {
    navigator.clipboard.writeText(email).then(function() {
        const btn = event.target.closest('.btn-copy-small');
        const originalIcon = btn.innerHTML;
        btn.innerHTML = '<i class="bi bi-check"></i>';
        btn.style.background = '#10b981';
        btn.style.color = '#ffffff';
        btn.style.borderColor = '#10b981';
        
        setTimeout(function() {
            btn.innerHTML = originalIcon;
            btn.style.background = '';
            btn.style.color = '';
            btn.style.borderColor = '';
        }, 2000);
    });
}

function togglePasswordVisibility() {
    const passwordText = document.getElementById('passwordText');
    const toggleIcon = document.getElementById('togglePasswordIcon');
    
    if (passwordText.textContent === '••••••••••••') {
        // Password is masked, show it if available
        passwordText.textContent = 'Password not available (reset required)';
        toggleIcon.classList.remove('bi-eye');
        toggleIcon.classList.add('bi-eye-slash');
    } else {
        // Password is shown, mask it
        passwordText.textContent = '••••••••••••';
        toggleIcon.classList.remove('bi-eye-slash');
        toggleIcon.classList.add('bi-eye');
    }
}

function confirmRemoveLogo() {
    if (confirm('Are you sure you want to remove the school logo?')) {
        document.getElementById('removeLogoInput').value = '1';
        document.querySelector('.current-logo').style.display = 'none';
    }
}

function copyAdminPassword(password) {
    navigator.clipboard.writeText(password).then(function() {
        const btn = event.target.closest('.btn-copy-small');
        const originalIcon = btn.innerHTML;
        btn.innerHTML = '<i class="bi bi-check"></i>';
        btn.style.background = '#10b981';
        btn.style.color = '#ffffff';
        btn.style.borderColor = '#10b981';
        
        setTimeout(function() {
            btn.innerHTML = originalIcon;
            btn.style.background = '';
            btn.style.color = '';
            btn.style.borderColor = '';
        }, 2000);
    });
}
</script>